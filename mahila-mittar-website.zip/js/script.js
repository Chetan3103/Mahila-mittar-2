function sos(){

alert("Emergency help is on the way! Call 112");

window.location.href="tel:112";

}
